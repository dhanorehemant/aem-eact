import processSPA from "./aem-processor.functions";

exports.processSPA = processSPA;
